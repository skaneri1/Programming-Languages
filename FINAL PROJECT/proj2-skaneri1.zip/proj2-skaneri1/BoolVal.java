public class BoolVal extends Value {
    public BoolVal(boolean place) {
	     boolean bool = place;
    }

    public String toString() {
	     return String.valueOf(bool);
    }
}
